/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "40c11f0269d478219957b0777a03bb5a"
  }, {
    "url": "pwa-512x512.png",
    "revision": "cd2c33823c42a376386ddff12e271e3d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "65cd440cc4e1f9f5ad8b4d0acdca5a48"
  }, {
    "url": "index.html",
    "revision": "1bf90347ebd65c48ab705c702d3608db"
  }, {
    "url": "icon.svg",
    "revision": "83172c342be17e090424910060431322"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5340b763bd59b1658ba49b018626776b"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/preview_jalapa_jutiapa_1793069617645-ubHYfRrP.jpg",
    "revision": null
  }, {
    "url": "assets/preview_campus_gt_1793069618087-DigKMKX8.jpg",
    "revision": null
  }, {
    "url": "assets/portada_juego_carros_1793411363803-3rFdJQDy.jpg",
    "revision": null
  }, {
    "url": "assets/place_san_miguel_duenas_1793071974463-CFThS8RY.jpg",
    "revision": null
  }, {
    "url": "assets/place_puertos_pacifico_gt_1793071976452-BvOKrmdc.jpg",
    "revision": null
  }, {
    "url": "assets/place_monjas_jalapa_1793073045304-Cw5zPJj1.jpg",
    "revision": null
  }, {
    "url": "assets/place_isla_flores_peten_1793071972843-BCgazLrv.jpg",
    "revision": null
  }, {
    "url": "assets/place_chiquimula_esquipulas_1793071976182-DK4x9alW.jpg",
    "revision": null
  }, {
    "url": "assets/place_autodromo_circuito_cerrado_1793080030758-DH4qS3r5.jpg",
    "revision": null
  }, {
    "url": "assets/people_pedestrians_real_1793073040945-qRWYa6F0.jpg",
    "revision": null
  }, {
    "url": "assets/madres_visera_trofeo_1793413035891-1-zaQU-Z.jpg",
    "revision": null
  }, {
    "url": "assets/index-Wa0soZrQ.js",
    "revision": null
  }, {
    "url": "assets/index-CV5lpTyT.css",
    "revision": null
  }, {
    "url": "assets/hero_guatemala_3d_drive_1793069617075-DPF0AK2K.jpg",
    "revision": null
  }, {
    "url": "assets/caratula_carros_dia_1793411363992-48USSZCx.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/IMG_20261022_112510_49dbacbd.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/Captura_de_pantalla_2026-10-30_22-37-32_87704239.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5340b763bd59b1658ba49b018626776b"
  }, {
    "url": "icon.svg",
    "revision": "83172c342be17e090424910060431322"
  }, {
    "url": "pwa-192x192.png",
    "revision": "65cd440cc4e1f9f5ad8b4d0acdca5a48"
  }, {
    "url": "pwa-512x512.png",
    "revision": "cd2c33823c42a376386ddff12e271e3d"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "40c11f0269d478219957b0777a03bb5a"
  }, {
    "url": "assets/aistudio/IMG_20261022_112510_49dbacbd.jpg",
    "revision": "123485c408c3bf05fa2b40224b86b00c"
  }, {
    "url": "manifest.webmanifest",
    "revision": "d1b6444c03d90e621ff95aeeef90097d"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/api\//, /^\/ws/]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    request
  }) => request.destination === "image", new workbox.CacheFirst({
    "cacheName": "local-images-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 60,
      maxAgeSeconds: 7776000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
